var index =
[
    [ "Wprowadzenie", "index.html#intro", null ],
    [ "Autorzy", "index.html#authors", null ],
    [ "Struktura dokumentacji", "index.html#structure", null ]
];