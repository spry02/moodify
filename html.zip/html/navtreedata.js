/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Moodify", "index.html", [
    [ "Dokumentacja projektu Moodify", "index.html", "index" ],
    [ "Streszczenie wykonawcze", "streszczenie.html", [
      [ "Streszczenie wykonawcze", "streszczenie.html#autotoc_md0", null ]
    ] ],
    [ "Opis projektu", "opis.html", [
      [ "Cel główny", "opis.html#autotoc_md1", null ],
      [ "Rozpoznawane emocje", "opis.html#autotoc_md2", null ],
      [ "Cele strategiczne", "opis.html#autotoc_md3", null ],
      [ "Zadania realizacyjne", "opis.html#autotoc_md4", null ]
    ] ],
    [ "Architektura systemu", "architektura.html", [
      [ "Architektura ogólna", "architektura.html#autotoc_md5", null ],
      [ "Przepływ danych", "architektura.html#autotoc_md6", null ]
    ] ],
    [ "Technologie", "technologie.html", [
      [ "Backend", "technologie.html#autotoc_md7", null ],
      [ "Frontend", "technologie.html#autotoc_md8", null ],
      [ "Infrastruktura", "technologie.html#autotoc_md9", null ]
    ] ],
    [ "Struktura projektu", "struktura.html", [
      [ "Drzewo katalogów", "struktura.html#autotoc_md10", null ]
    ] ],
    [ "Frontend (React + TypeScript)", "frontend.html", [
      [ "Główne komponenty", "frontend.html#autotoc_md11", [
        [ "Cechy", "frontend.html#autotoc_md12", null ],
        [ "Architektura i struktura", "frontend.html#autotoc_md13", [
          [ "Struktura katalogów", "frontend.html#autotoc_md14", null ]
        ] ]
      ] ],
      [ "Konfiguracja", "frontend.html#autotoc_md15", [
        [ "Vite Configuration (vite.config.ts)", "frontend.html#autotoc_md16", null ],
        [ "TypeScript (tsconfig.json)", "frontend.html#autotoc_md17", null ],
        [ "Tailwind CSS", "frontend.html#autotoc_md18", null ]
      ] ],
      [ "Komponenty", "frontend.html#autotoc_md20", [
        [ "Główny punkt wejścia: App.tsx", "frontend.html#autotoc_md21", null ],
        [ "Dashboard: MainDashboard.tsx", "frontend.html#autotoc_md23", null ],
        [ "Komponenty formularzy", "frontend.html#autotoc_md25", [
          [ "AddMoodForm.tsx", "frontend.html#autotoc_md26", null ],
          [ "MoodSelectPanel.tsx", "frontend.html#autotoc_md27", null ],
          [ "DescriptionBox.tsx", "frontend.html#autotoc_md28", null ],
          [ "CameraBox.tsx", "frontend.html#autotoc_md29", null ]
        ] ],
        [ "Komponenty danych i wyników", "frontend.html#autotoc_md31", [
          [ "SongsList.tsx", "frontend.html#autotoc_md32", null ],
          [ "PlaylistsList.tsx", "frontend.html#autotoc_md33", null ],
          [ "MoodsList.tsx", "frontend.html#autotoc_md34", null ],
          [ "Recommendations.tsx / RecommendationsSummary.tsx", "frontend.html#autotoc_md35", null ],
          [ "AnalysisResult.tsx", "frontend.html#autotoc_md36", null ]
        ] ],
        [ "Komponenty UI i nawigacji", "frontend.html#autotoc_md38", [
          [ "Card.tsx", "frontend.html#autotoc_md39", null ],
          [ "ControlToggles.tsx", "frontend.html#autotoc_md40", null ],
          [ "GenerateButton.tsx", "frontend.html#autotoc_md41", null ],
          [ "ThemeToggle.tsx", "frontend.html#autotoc_md42", null ]
        ] ],
        [ "Komponenty autentykacji: Auth/", "frontend.html#autotoc_md44", [
          [ "AuthPopup.tsx", "frontend.html#autotoc_md45", null ],
          [ "LoginForm.tsx", "frontend.html#autotoc_md46", null ],
          [ "RegisterForm.tsx", "frontend.html#autotoc_md47", null ],
          [ "ProfileModal.tsx", "frontend.html#autotoc_md48", null ],
          [ "UserPanel.tsx", "frontend.html#autotoc_md49", null ]
        ] ]
      ] ]
    ] ],
    [ "API", "api.html", [
      [ "Autentykacja", "api.html#autotoc_md55", [
        [ "Plik: components/api/api.ts", "api.html#autotoc_md51", [
          [ "Mock API (do testowania bez backendu)", "api.html#autotoc_md52", null ],
          [ "API Backend (rzeczywiste)", "api.html#autotoc_md53", null ]
        ] ],
        [ "Konfiguracja Firebase: components/firebase/firebase.ts", "api.html#autotoc_md56", null ]
      ] ],
      [ "Typy TypeScript", "api.html#autotoc_md58", [
        [ "components/types/types.ts", "api.html#autotoc_md59", null ],
        [ "Interfejsy komponentów", "api.html#autotoc_md60", null ]
      ] ],
      [ "Instalacja i uruchomienie", "api.html#autotoc_md62", [
        [ "Wymagania", "api.html#autotoc_md63", null ],
        [ "Instalacja zależności", "api.html#autotoc_md64", null ],
        [ "Uruchomienie w trybie development", "api.html#autotoc_md65", null ],
        [ "Build do produkcji", "api.html#autotoc_md66", null ],
        [ "Preview built version", "api.html#autotoc_md67", null ]
      ] ],
      [ "Stylowanie", "api.html#autotoc_md69", [
        [ "Framework: Tailwind CSS", "api.html#autotoc_md70", null ],
        [ "Zmienne tematu: MainDashboard.tsx", "api.html#autotoc_md71", null ],
        [ "Struktura CSS", "api.html#autotoc_md72", null ],
        [ "System kolorów", "api.html#autotoc_md73", null ],
        [ "LocalStorage", "api.html#autotoc_md74", null ]
      ] ],
      [ "Przepływ danych", "api.html#autotoc_md76", null ],
      [ "Zmienne środowiska", "api.html#autotoc_md78", null ],
      [ "Notatki dla deweloperów", "api.html#autotoc_md80", null ],
      [ "Ścieżka weryfikacji", "api.html#autotoc_md81", null ]
    ] ],
    [ "Backend API (FastAPI)", "backend.html", [
      [ "Zakres i cel", "backend.html#autotoc_md82", null ],
      [ "Struktura folderu", "backend.html#autotoc_md83", null ],
      [ "Zrodla danych i mapowanie emocji", "backend.html#autotoc_md84", null ],
      [ "Preprocessing danych (data_preprocessing.ipynb)", "backend.html#autotoc_md85", null ],
      [ "Trening modelu tekstowego (model_training.ipynb)", "backend.html#autotoc_md86", null ],
      [ "Trening modelu obrazowego - wersja bazowa (backend/model_training.ipynb)", "backend.html#autotoc_md87", null ],
      [ "Trening modelu obrazowego - wersja rozszerzona (backend/models/model_training.ipynb)", "backend.html#autotoc_md88", null ],
      [ "Analiza zbiorow (moodify_datasets_analysis.ipynb)", "backend.html#autotoc_md89", null ],
      [ "Test predykcji (backend/models/test_predictions.ipynb)", "backend.html#autotoc_md90", null ],
      [ "Keras Tuner (backend/models/keras_tuner)", "backend.html#autotoc_md91", null ],
      [ "Zaleznosci", "backend.html#autotoc_md92", null ],
      [ "Typowy przebieg pracy", "backend.html#autotoc_md93", null ],
      [ "Uwaga o duplikacji", "backend.html#autotoc_md94", null ]
    ] ],
    [ "Firebase", "firebase.html", [
      [ "Informacje Ogólne", "firebase.html#autotoc_md95", null ],
      [ "Konfiguracja Klienta (Frontend)", "firebase.html#autotoc_md96", [
        [ "Zainicjalizowane usługi", "firebase.html#autotoc_md97", null ],
        [ "Obiekt konfiguracyjny", "firebase.html#autotoc_md98", null ]
      ] ],
      [ "Konfiguracja Serwera (Backend)", "firebase.html#autotoc_md99", [
        [ "Inicjalizacja", "firebase.html#autotoc_md100", null ],
        [ "Zmienne środowiskowe", "firebase.html#autotoc_md101", null ]
      ] ],
      [ "Uwierzytelnianie", "firebase.html#autotoc_md102", [
        [ "Metody logowania", "firebase.html#autotoc_md103", null ],
        [ "Backend API (api/services/firebase.py)", "firebase.html#autotoc_md104", null ],
        [ "Frontend", "firebase.html#autotoc_md105", null ]
      ] ],
      [ "Baza Danych (Cloud Firestore)", "firebase.html#autotoc_md106", [
        [ "Struktura Kolekcji", "firebase.html#autotoc_md107", [
          [ "Kolekcja users", "firebase.html#autotoc_md108", null ],
          [ "Podkolekcja moods", "firebase.html#autotoc_md109", null ]
        ] ]
      ] ],
      [ "Operacje na Danych (Serwisy)", "firebase.html#autotoc_md110", null ],
      [ "Endpointy API powiązane z Firebase", "firebase.html#autotoc_md111", null ]
    ] ],
    [ "Machine Learning", "ml.html", [
      [ "Datasety", "ml.html#autotoc_md112", [
        [ "AffectNet", "ml.html#autotoc_md113", [
          [ "Emotion Dataset", "ml.html#autotoc_md114", null ]
        ] ]
      ] ],
      [ "Modele", "ml.html#autotoc_md115", [
        [ "Model CNN dla obrazów", "ml.html#autotoc_md116", null ],
        [ "Model SVM dla tekstu", "ml.html#autotoc_md117", [
          [ "Metryki", "ml.html#autotoc_md118", null ]
        ] ]
      ] ],
      [ "Preprocessing", "ml.html#autotoc_md119", null ]
    ] ],
    [ "Instalacja i uruchomienie", "instalacja.html", [
      [ "Wymagania systemowe", "instalacja.html#autotoc_md120", null ],
      [ "Konfiguracja wstępna", "instalacja.html#autotoc_md121", [
        [ "Backend Setup", "instalacja.html#autotoc_md125", [
          [ "1. Clone repozytorium", "instalacja.html#autotoc_md122", null ],
          [ "2. Przygotowanie Firebase", "instalacja.html#autotoc_md123", null ],
          [ "3. Spotify API", "instalacja.html#autotoc_md124", null ],
          [ "Kroki:", "instalacja.html#autotoc_md126", null ]
        ] ],
        [ "Frontend Setup", "instalacja.html#autotoc_md127", [
          [ "Kroki:", "instalacja.html#autotoc_md128", null ],
          [ "Jeśli chcesz trenować modele:", "instalacja.html#autotoc_md129", null ]
        ] ],
        [ "Weryfikacja instalacji", "instalacja.html#autotoc_md130", null ]
      ] ]
    ] ],
    [ "Wnioski i podsumowanie", "wnioski.html", [
      [ "Osiągnięcia", "wnioski.html#autotoc_md131", null ],
      [ "Mocne strony", "wnioski.html#autotoc_md132", null ],
      [ "Obszary do usprawnienia", "wnioski.html#autotoc_md133", null ],
      [ "Rekomendacje", "wnioski.html#autotoc_md134", null ],
      [ "Potencjał biznesowy", "wnioski.html#autotoc_md135", null ]
    ] ],
    [ "Kontakt i wsparcie", "kontakt.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"api.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';