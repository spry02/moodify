var searchData=
[
  ['backend_20api_20fastapi_0',['Backend API (FastAPI)',['../backend.html',1,'']]]
];
