var searchData=
[
  ['ścieżka_20weryfikacji_0',['Ścieżka weryfikacji',['../frontend.html#autotoc_md82',1,'']]],
  ['środowiska_1',['Zmienne środowiska',['../frontend.html#autotoc_md79',1,'']]],
  ['środowiskowe_2',['Zmienne środowiskowe',['../backend.html#autotoc_md90',1,'']]]
];
