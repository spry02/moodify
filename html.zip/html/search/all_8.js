var searchData=
[
  ['fastapi_0',['Backend API (FastAPI)',['../backend.html',1,'']]],
  ['firebase_1',['firebase',['../instalacja.html#autotoc_md123',1,'2. Przygotowanie Firebase'],['../firebase.html#autotoc_md111',1,'Endpointy API powiązane z Firebase'],['../firebase.html',1,'Firebase']]],
  ['firebase_20firebase_20ts_2',['Konfiguracja Firebase: components/firebase/firebase.ts',['../api.html#autotoc_md56',1,'']]],
  ['firebase_20py_3',['Backend API (api/services/firebase.py)',['../firebase.html#autotoc_md104',1,'']]],
  ['firebase_3a_20components_20firebase_20firebase_20ts_4',['Konfiguracja Firebase: components/firebase/firebase.ts',['../api.html#autotoc_md56',1,'']]],
  ['firestore_5',['Baza Danych (Cloud Firestore)',['../firebase.html#autotoc_md106',1,'']]],
  ['folderu_6',['Struktura folderu',['../backend.html#autotoc_md83',1,'']]],
  ['formularzy_7',['Komponenty formularzy',['../frontend.html#autotoc_md25',1,'']]],
  ['framework_3a_20tailwind_20css_8',['Framework: Tailwind CSS',['../api.html#autotoc_md70',1,'']]],
  ['frontend_9',['frontend',['../technologie.html#autotoc_md8',1,'Frontend'],['../firebase.html#autotoc_md105',1,'Frontend'],['../firebase.html#autotoc_md96',1,'Konfiguracja Klienta (Frontend)']]],
  ['frontend_20react_20typescript_10',['Frontend (React + TypeScript)',['../frontend.html',1,'']]],
  ['frontend_20setup_11',['Frontend Setup',['../instalacja.html#autotoc_md127',1,'']]]
];
