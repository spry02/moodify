var searchData=
[
  ['streszczenie_20wykonawcze_0',['Streszczenie wykonawcze',['../streszczenie.html',1,'']]],
  ['struktura_20projektu_1',['Struktura projektu',['../struktura.html',1,'']]],
  ['systemu_2',['Architektura systemu',['../architektura.html',1,'']]]
];
