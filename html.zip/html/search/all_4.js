var searchData=
[
  ['backend_0',['backend',['../technologie.html#autotoc_md7',1,'Backend'],['../firebase.html#autotoc_md99',1,'Konfiguracja Serwera (Backend)']]],
  ['backend_20api_20api_20services_20firebase_20py_1',['Backend API (api/services/firebase.py)',['../firebase.html#autotoc_md104',1,'']]],
  ['backend_20api_20fastapi_2',['Backend API (FastAPI)',['../backend.html',1,'']]],
  ['backend_20model_5ftraining_20ipynb_3',['Trening modelu obrazowego - wersja bazowa (backend/model_training.ipynb)',['../backend.html#autotoc_md87',1,'']]],
  ['backend_20models_20keras_5ftuner_4',['Keras Tuner (backend/models/keras_tuner)',['../backend.html#autotoc_md91',1,'']]],
  ['backend_20models_20model_5ftraining_20ipynb_5',['Trening modelu obrazowego - wersja rozszerzona (backend/models/model_training.ipynb)',['../backend.html#autotoc_md88',1,'']]],
  ['backend_20models_20test_5fpredictions_20ipynb_6',['Test predykcji (backend/models/test_predictions.ipynb)',['../backend.html#autotoc_md90',1,'']]],
  ['backend_20rzeczywiste_7',['API Backend (rzeczywiste)',['../api.html#autotoc_md53',1,'']]],
  ['backend_20setup_8',['Backend Setup',['../instalacja.html#autotoc_md125',1,'']]],
  ['backendu_9',['Mock API (do testowania bez backendu)',['../api.html#autotoc_md52',1,'']]],
  ['baza_20danych_20cloud_20firestore_10',['Baza Danych (Cloud Firestore)',['../firebase.html#autotoc_md106',1,'']]],
  ['bazowa_20backend_20model_5ftraining_20ipynb_11',['Trening modelu obrazowego - wersja bazowa (backend/model_training.ipynb)',['../backend.html#autotoc_md87',1,'']]],
  ['bez_20backendu_12',['Mock API (do testowania bez backendu)',['../api.html#autotoc_md52',1,'']]],
  ['biznesowy_13',['Potencjał biznesowy',['../wnioski.html#autotoc_md135',1,'']]],
  ['build_20do_20produkcji_14',['Build do produkcji',['../api.html#autotoc_md66',1,'']]],
  ['built_20version_15',['Preview built version',['../api.html#autotoc_md67',1,'']]]
];
