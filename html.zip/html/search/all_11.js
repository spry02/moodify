var searchData=
[
  ['playlistslist_20tsx_0',['PlaylistsList.tsx',['../frontend.html#autotoc_md33',1,'']]],
  ['plik_3a_20components_20api_20api_20ts_1',['Plik: components/api/api.ts',['../api.html#autotoc_md51',1,'']]],
  ['podkolekcja_20moods_2',['Podkolekcja moods',['../firebase.html#autotoc_md109',1,'']]],
  ['podsumowanie_3',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['potencjał_20biznesowy_4',['Potencjał biznesowy',['../wnioski.html#autotoc_md135',1,'']]],
  ['powiązane_20z_20firebase_5',['Endpointy API powiązane z Firebase',['../firebase.html#autotoc_md111',1,'']]],
  ['pracy_6',['Typowy przebieg pracy',['../backend.html#autotoc_md93',1,'']]],
  ['predykcji_20backend_20models_20test_5fpredictions_20ipynb_7',['Test predykcji (backend/models/test_predictions.ipynb)',['../backend.html#autotoc_md90',1,'']]],
  ['preprocessing_8',['Preprocessing',['../ml.html#autotoc_md119',1,'']]],
  ['preprocessing_20danych_20data_5fpreprocessing_20ipynb_9',['Preprocessing danych (data_preprocessing.ipynb)',['../backend.html#autotoc_md85',1,'']]],
  ['preview_20built_20version_10',['Preview built version',['../api.html#autotoc_md67',1,'']]],
  ['produkcji_11',['Build do produkcji',['../api.html#autotoc_md66',1,'']]],
  ['profilemodal_20tsx_12',['ProfileModal.tsx',['../frontend.html#autotoc_md48',1,'']]],
  ['projektu_13',['projektu',['../opis.html',1,'Opis projektu'],['../struktura.html',1,'Struktura projektu']]],
  ['projektu_20moodify_14',['Dokumentacja projektu Moodify',['../index.html',1,'']]],
  ['przebieg_20pracy_15',['Typowy przebieg pracy',['../backend.html#autotoc_md93',1,'']]],
  ['przepływ_20danych_16',['przepływ danych',['../api.html#autotoc_md76',1,'Przepływ danych'],['../architektura.html#autotoc_md6',1,'Przepływ danych']]],
  ['przygotowanie_20firebase_17',['2. Przygotowanie Firebase',['../instalacja.html#autotoc_md123',1,'']]],
  ['punkt_20wejścia_3a_20app_20tsx_18',['Główny punkt wejścia: App.tsx',['../frontend.html#autotoc_md21',1,'']]],
  ['py_19',['Backend API (api/services/firebase.py)',['../firebase.html#autotoc_md104',1,'']]]
];
