var searchData=
[
  ['i_20podsumowanie_0',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['i_20uruchomienie_1',['Instalacja i uruchomienie',['../instalacja.html',1,'']]],
  ['i_20wsparcie_2',['Kontakt i wsparcie',['../kontakt.html',1,'']]],
  ['instalacja_20i_20uruchomienie_3',['Instalacja i uruchomienie',['../instalacja.html',1,'']]]
];
