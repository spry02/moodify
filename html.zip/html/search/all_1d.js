var searchData=
[
  ['w_20trybie_20development_0',['Uruchomienie w trybie development',['../frontend.html#autotoc_md66',1,'']]],
  ['wejścia_3a_20app_20tsx_1',['Główny punkt wejścia: App.tsx',['../frontend.html#autotoc_md21',1,'']]],
  ['weryfikacja_20instalacji_2',['Weryfikacja instalacji',['../instalacja.html#autotoc_md122',1,'']]],
  ['weryfikacji_3',['Ścieżka weryfikacji',['../frontend.html#autotoc_md82',1,'']]],
  ['wnioski_20i_20podsumowanie_4',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['wsparcie_5',['Kontakt i wsparcie',['../wnioski.html#autotoc_md133',1,'']]],
  ['wstępna_6',['Konfiguracja wstępna',['../instalacja.html#autotoc_md116',1,'']]],
  ['wykonawcze_7',['wykonawcze',['../streszczenie.html',1,'Streszczenie wykonawcze'],['../streszczenie.html#autotoc_md0',1,'Streszczenie wykonawcze']]],
  ['wymagania_8',['Wymagania',['../frontend.html#autotoc_md64',1,'']]],
  ['wymagania_20systemowe_9',['Wymagania systemowe',['../instalacja.html#autotoc_md115',1,'']]],
  ['wyników_10',['Komponenty danych i wyników',['../frontend.html#autotoc_md31',1,'']]]
];
