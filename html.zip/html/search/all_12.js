var searchData=
[
  ['react_20typescript_0',['Frontend (React + TypeScript)',['../frontend.html',1,'']]],
  ['realizacyjne_1',['Zadania realizacyjne',['../opis.html#autotoc_md4',1,'']]],
  ['recommendations_20tsx_20recommendationssummary_20tsx_2',['Recommendations.tsx / RecommendationsSummary.tsx',['../frontend.html#autotoc_md35',1,'']]],
  ['recommendationssummary_20tsx_3',['Recommendations.tsx / RecommendationsSummary.tsx',['../frontend.html#autotoc_md35',1,'']]],
  ['registerform_20tsx_4',['RegisterForm.tsx',['../frontend.html#autotoc_md47',1,'']]],
  ['rekomendacje_5',['Rekomendacje',['../wnioski.html#autotoc_md134',1,'']]],
  ['repozytorium_6',['1. Clone repozytorium',['../instalacja.html#autotoc_md122',1,'']]],
  ['rozpoznawane_20emocje_7',['Rozpoznawane emocje',['../opis.html#autotoc_md2',1,'']]],
  ['rozszerzona_20backend_20models_20model_5ftraining_20ipynb_8',['Trening modelu obrazowego - wersja rozszerzona (backend/models/model_training.ipynb)',['../backend.html#autotoc_md88',1,'']]],
  ['rzeczywiste_9',['API Backend (rzeczywiste)',['../api.html#autotoc_md53',1,'']]]
];
