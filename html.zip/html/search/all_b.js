var searchData=
[
  ['jeśli_20chcesz_20trenować_20modele_3a_0',['Jeśli chcesz trenować modele:',['../instalacja.html#autotoc_md129',1,'']]],
  ['json_1',['TypeScript (tsconfig.json)',['../frontend.html#autotoc_md17',1,'']]]
];
