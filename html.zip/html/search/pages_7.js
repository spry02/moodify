var searchData=
[
  ['machine_20learning_0',['Machine Learning',['../ml.html',1,'']]],
  ['moodify_1',['Dokumentacja projektu Moodify',['../index.html',1,'']]]
];
