var searchData=
[
  ['emocje_0',['Rozpoznawane emocje',['../opis.html#autotoc_md2',1,'']]],
  ['emocji_1',['Zrodla danych i mapowanie emocji',['../backend.html#autotoc_md84',1,'']]],
  ['emotion_20dataset_2',['Emotion Dataset',['../ml.html#autotoc_md114',1,'']]],
  ['endpointy_20api_20powiązane_20z_20firebase_3',['Endpointy API powiązane z Firebase',['../firebase.html#autotoc_md111',1,'']]]
];
