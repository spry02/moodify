var searchData=
[
  ['services_20firebase_20py_0',['Backend API (api/services/firebase.py)',['../firebase.html#autotoc_md104',1,'']]],
  ['serwera_20backend_1',['Konfiguracja Serwera (Backend)',['../firebase.html#autotoc_md99',1,'']]],
  ['serwisy_2',['Operacje na Danych (Serwisy)',['../firebase.html#autotoc_md110',1,'']]],
  ['setup_3',['setup',['../instalacja.html#autotoc_md125',1,'Backend Setup'],['../instalacja.html#autotoc_md127',1,'Frontend Setup']]],
  ['songslist_20tsx_4',['SongsList.tsx',['../frontend.html#autotoc_md32',1,'']]],
  ['spotify_20api_5',['3. Spotify API',['../instalacja.html#autotoc_md124',1,'']]],
  ['strategiczne_6',['Cele strategiczne',['../opis.html#autotoc_md3',1,'']]],
  ['streszczenie_20wykonawcze_7',['streszczenie wykonawcze',['../streszczenie.html#autotoc_md0',1,'Streszczenie wykonawcze'],['../streszczenie.html',1,'Streszczenie wykonawcze']]],
  ['strony_8',['Mocne strony',['../wnioski.html#autotoc_md132',1,'']]],
  ['struktura_9',['Architektura i struktura',['../frontend.html#autotoc_md13',1,'']]],
  ['struktura_20css_10',['Struktura CSS',['../api.html#autotoc_md72',1,'']]],
  ['struktura_20dokumentacji_11',['Struktura dokumentacji',['../index.html#structure',1,'']]],
  ['struktura_20folderu_12',['Struktura folderu',['../backend.html#autotoc_md83',1,'']]],
  ['struktura_20katalogów_13',['Struktura katalogów',['../frontend.html#autotoc_md14',1,'']]],
  ['struktura_20kolekcji_14',['Struktura Kolekcji',['../firebase.html#autotoc_md107',1,'']]],
  ['struktura_20projektu_15',['Struktura projektu',['../struktura.html',1,'']]],
  ['stylowanie_16',['Stylowanie',['../api.html#autotoc_md69',1,'']]],
  ['svm_20dla_20tekstu_17',['Model SVM dla tekstu',['../ml.html#autotoc_md117',1,'']]],
  ['system_20kolorów_18',['System kolorów',['../api.html#autotoc_md73',1,'']]],
  ['systemowe_19',['Wymagania systemowe',['../instalacja.html#autotoc_md120',1,'']]],
  ['systemu_20',['Architektura systemu',['../architektura.html',1,'']]]
];
