var searchData=
[
  ['opis_20projektu_0',['Opis projektu',['../opis.html',1,'']]]
];
