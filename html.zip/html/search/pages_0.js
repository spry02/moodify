var searchData=
[
  ['api_0',['API',['../api.html',1,'']]],
  ['api_20fastapi_1',['Backend API (FastAPI)',['../backend.html',1,'']]],
  ['architektura_20systemu_2',['Architektura systemu',['../architektura.html',1,'']]]
];
