var searchData=
[
  ['podsumowanie_0',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['projektu_1',['projektu',['../opis.html',1,'Opis projektu'],['../struktura.html',1,'Struktura projektu']]],
  ['projektu_20moodify_2',['Dokumentacja projektu Moodify',['../index.html',1,'']]]
];
