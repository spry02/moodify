var searchData=
[
  ['fastapi_0',['Backend API (FastAPI)',['../backend.html',1,'']]],
  ['firebase_1',['Firebase',['../firebase.html',1,'']]],
  ['frontend_20react_20typescript_2',['Frontend (React + TypeScript)',['../frontend.html',1,'']]]
];
