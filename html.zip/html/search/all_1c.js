var searchData=
[
  ['version_0',['Preview built version',['../frontend.html#autotoc_md68',1,'']]],
  ['vite_20config_20ts_1',['Vite Configuration (vite.config.ts)',['../frontend.html#autotoc_md16',1,'']]],
  ['vite_20configuration_20vite_20config_20ts_2',['Vite Configuration (vite.config.ts)',['../frontend.html#autotoc_md16',1,'']]]
];
