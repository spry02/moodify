var searchData=
[
  ['3_20spotify_20api_0',['3. Spotify API',['../instalacja.html#autotoc_md124',1,'']]]
];
