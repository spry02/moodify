var searchData=
[
  ['learning_0',['Machine Learning',['../ml.html',1,'']]]
];
