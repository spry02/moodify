var searchData=
[
  ['technologie_0',['Technologie',['../technologie.html',1,'']]],
  ['typescript_1',['Frontend (React + TypeScript)',['../frontend.html',1,'']]]
];
