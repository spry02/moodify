var searchData=
[
  ['w_20trybie_20development_0',['Uruchomienie w trybie development',['../api.html#autotoc_md65',1,'']]],
  ['wejścia_3a_20app_20tsx_1',['Główny punkt wejścia: App.tsx',['../frontend.html#autotoc_md21',1,'']]],
  ['wersja_20bazowa_20backend_20model_5ftraining_20ipynb_2',['Trening modelu obrazowego - wersja bazowa (backend/model_training.ipynb)',['../backend.html#autotoc_md87',1,'']]],
  ['wersja_20rozszerzona_20backend_20models_20model_5ftraining_20ipynb_3',['Trening modelu obrazowego - wersja rozszerzona (backend/models/model_training.ipynb)',['../backend.html#autotoc_md88',1,'']]],
  ['weryfikacja_20instalacji_4',['Weryfikacja instalacji',['../instalacja.html#autotoc_md130',1,'']]],
  ['weryfikacji_5',['Ścieżka weryfikacji',['../api.html#autotoc_md81',1,'']]],
  ['wnioski_20i_20podsumowanie_6',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['wprowadzenie_7',['Wprowadzenie',['../index.html#intro',1,'']]],
  ['wsparcie_8',['Kontakt i wsparcie',['../kontakt.html',1,'']]],
  ['wstępna_9',['Konfiguracja wstępna',['../instalacja.html#autotoc_md121',1,'']]],
  ['wykonawcze_10',['wykonawcze',['../streszczenie.html',1,'Streszczenie wykonawcze'],['../streszczenie.html#autotoc_md0',1,'Streszczenie wykonawcze']]],
  ['wymagania_11',['Wymagania',['../api.html#autotoc_md63',1,'']]],
  ['wymagania_20systemowe_12',['Wymagania systemowe',['../instalacja.html#autotoc_md120',1,'']]],
  ['wyników_13',['Komponenty danych i wyników',['../frontend.html#autotoc_md31',1,'']]]
];
