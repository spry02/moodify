var searchData=
[
  ['learning_0',['Machine Learning',['../ml.html',1,'']]],
  ['localstorage_1',['LocalStorage',['../api.html#autotoc_md74',1,'']]],
  ['loginform_20tsx_2',['LoginForm.tsx',['../frontend.html#autotoc_md46',1,'']]],
  ['logowania_3',['Metody logowania',['../firebase.html#autotoc_md103',1,'']]]
];
