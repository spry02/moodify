var searchData=
[
  ['tailwind_20css_0',['tailwind css',['../frontend.html#autotoc_md71',1,'Framework: Tailwind CSS'],['../frontend.html#autotoc_md18',1,'Tailwind CSS']]],
  ['technologie_1',['Technologie',['../technologie.html',1,'']]],
  ['tekst_20test_2078_20ndash_20ndash_20ndash_2',['SVM         Tekst          Test        ~78%          &amp;ndash;              &amp;ndash;           &amp;ndash;',['../ml.html#autotoc_md112',1,'']]],
  ['tekstu_3',['Model SVM dla tekstu',['../ml.html#autotoc_md108',1,'']]],
  ['tematu_3a_20maindashboard_20tsx_4',['Zmienne tematu: MainDashboard.tsx',['../frontend.html#autotoc_md72',1,'']]],
  ['test_2078_20ndash_20ndash_20ndash_5',['SVM         Tekst          Test        ~78%          &amp;ndash;              &amp;ndash;           &amp;ndash;',['../ml.html#autotoc_md112',1,'']]],
  ['testowania_20bez_20backendu_6',['Mock API (do testowania bez backendu)',['../frontend.html#autotoc_md53',1,'']]],
  ['themetoggle_20tsx_7',['ThemeToggle.tsx',['../frontend.html#autotoc_md42',1,'']]],
  ['trybie_20development_8',['Uruchomienie w trybie development',['../frontend.html#autotoc_md66',1,'']]],
  ['ts_9',['ts',['../frontend.html#autotoc_md60',1,'components/types/types.ts'],['../frontend.html#autotoc_md57',1,'Konfiguracja Firebase: components/firebase/firebase.ts'],['../frontend.html#autotoc_md52',1,'Plik: components/api/api.ts'],['../frontend.html#autotoc_md16',1,'Vite Configuration (vite.config.ts)']]],
  ['tsconfig_20json_10',['TypeScript (tsconfig.json)',['../frontend.html#autotoc_md17',1,'']]],
  ['tsx_11',['tsx',['../frontend.html#autotoc_md26',1,'AddMoodForm.tsx'],['../frontend.html#autotoc_md36',1,'AnalysisResult.tsx'],['../frontend.html#autotoc_md45',1,'AuthPopup.tsx'],['../frontend.html#autotoc_md29',1,'CameraBox.tsx'],['../frontend.html#autotoc_md39',1,'Card.tsx'],['../frontend.html#autotoc_md40',1,'ControlToggles.tsx'],['../frontend.html#autotoc_md23',1,'Dashboard: MainDashboard.tsx'],['../frontend.html#autotoc_md28',1,'DescriptionBox.tsx'],['../frontend.html#autotoc_md21',1,'Główny punkt wejścia: App.tsx'],['../frontend.html#autotoc_md41',1,'GenerateButton.tsx'],['../frontend.html#autotoc_md46',1,'LoginForm.tsx'],['../frontend.html#autotoc_md27',1,'MoodSelectPanel.tsx'],['../frontend.html#autotoc_md34',1,'MoodsList.tsx'],['../frontend.html#autotoc_md33',1,'PlaylistsList.tsx'],['../frontend.html#autotoc_md48',1,'ProfileModal.tsx'],['../frontend.html#autotoc_md47',1,'RegisterForm.tsx'],['../frontend.html#autotoc_md32',1,'SongsList.tsx'],['../frontend.html#autotoc_md42',1,'ThemeToggle.tsx'],['../frontend.html#autotoc_md49',1,'UserPanel.tsx'],['../frontend.html#autotoc_md72',1,'Zmienne tematu: MainDashboard.tsx']]],
  ['tsx_20recommendationssummary_20tsx_12',['Recommendations.tsx / RecommendationsSummary.tsx',['../frontend.html#autotoc_md35',1,'']]],
  ['types_20types_20ts_13',['components/types/types.ts',['../frontend.html#autotoc_md60',1,'']]],
  ['typescript_14',['typescript',['../frontend.html',1,'Frontend (React + TypeScript)'],['../frontend.html#autotoc_md59',1,'Typy TypeScript']]],
  ['typescript_20tsconfig_20json_15',['TypeScript (tsconfig.json)',['../frontend.html#autotoc_md17',1,'']]],
  ['typy_20typescript_16',['Typy TypeScript',['../frontend.html#autotoc_md59',1,'']]]
];
