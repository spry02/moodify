var searchData=
[
  ['1_20clone_20repozytorium_0',['1. Clone repozytorium',['../instalacja.html#autotoc_md122',1,'']]]
];
