var searchData=
[
  ['camerabox_20tsx_0',['CameraBox.tsx',['../frontend.html#autotoc_md29',1,'']]],
  ['card_20tsx_1',['Card.tsx',['../frontend.html#autotoc_md39',1,'']]],
  ['cechy_2',['Cechy',['../frontend.html#autotoc_md12',1,'']]],
  ['cel_3',['Zakres i cel',['../backend.html#autotoc_md82',1,'']]],
  ['cel_20główny_4',['Cel główny',['../opis.html#autotoc_md1',1,'']]],
  ['cele_20strategiczne_5',['Cele strategiczne',['../opis.html#autotoc_md3',1,'']]],
  ['chcesz_20trenować_20modele_3a_6',['Jeśli chcesz trenować modele:',['../instalacja.html#autotoc_md129',1,'']]],
  ['clone_20repozytorium_7',['1. Clone repozytorium',['../instalacja.html#autotoc_md122',1,'']]],
  ['cloud_20firestore_8',['Baza Danych (Cloud Firestore)',['../firebase.html#autotoc_md106',1,'']]],
  ['cnn_20dla_20obrazów_9',['Model CNN dla obrazów',['../ml.html#autotoc_md116',1,'']]],
  ['components_20api_20api_20ts_10',['Plik: components/api/api.ts',['../api.html#autotoc_md51',1,'']]],
  ['components_20firebase_20firebase_20ts_11',['Konfiguracja Firebase: components/firebase/firebase.ts',['../api.html#autotoc_md56',1,'']]],
  ['components_20types_20types_20ts_12',['components/types/types.ts',['../api.html#autotoc_md59',1,'']]],
  ['config_20ts_13',['Vite Configuration (vite.config.ts)',['../frontend.html#autotoc_md16',1,'']]],
  ['configuration_20vite_20config_20ts_14',['Vite Configuration (vite.config.ts)',['../frontend.html#autotoc_md16',1,'']]],
  ['controltoggles_20tsx_15',['ControlToggles.tsx',['../frontend.html#autotoc_md40',1,'']]],
  ['css_16',['css',['../api.html#autotoc_md70',1,'Framework: Tailwind CSS'],['../api.html#autotoc_md72',1,'Struktura CSS'],['../frontend.html#autotoc_md18',1,'Tailwind CSS']]]
];
