var searchData=
[
  ['zadania_0',['Cele i zadania',['../cele.html',1,'']]]
];
