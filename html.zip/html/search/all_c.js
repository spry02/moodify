var searchData=
[
  ['katalogów_0',['katalogów',['../struktura.html#autotoc_md10',1,'Drzewo katalogów'],['../frontend.html#autotoc_md14',1,'Struktura katalogów']]],
  ['keras_20tuner_20backend_20models_20keras_5ftuner_1',['Keras Tuner (backend/models/keras_tuner)',['../backend.html#autotoc_md91',1,'']]],
  ['keras_5ftuner_2',['Keras Tuner (backend/models/keras_tuner)',['../backend.html#autotoc_md91',1,'']]],
  ['klienta_20frontend_3',['Konfiguracja Klienta (Frontend)',['../firebase.html#autotoc_md96',1,'']]],
  ['kolekcja_20users_4',['Kolekcja users',['../firebase.html#autotoc_md108',1,'']]],
  ['kolekcji_5',['Struktura Kolekcji',['../firebase.html#autotoc_md107',1,'']]],
  ['kolorów_6',['System kolorów',['../api.html#autotoc_md73',1,'']]],
  ['komponentów_7',['Interfejsy komponentów',['../api.html#autotoc_md60',1,'']]],
  ['komponenty_8',['komponenty',['../frontend.html#autotoc_md11',1,'Główne komponenty'],['../frontend.html#autotoc_md20',1,'Komponenty']]],
  ['komponenty_20autentykacji_3a_20auth_9',['Komponenty autentykacji: Auth/',['../frontend.html#autotoc_md44',1,'']]],
  ['komponenty_20danych_20i_20wyników_10',['Komponenty danych i wyników',['../frontend.html#autotoc_md31',1,'']]],
  ['komponenty_20formularzy_11',['Komponenty formularzy',['../frontend.html#autotoc_md25',1,'']]],
  ['komponenty_20ui_20i_20nawigacji_12',['Komponenty UI i nawigacji',['../frontend.html#autotoc_md38',1,'']]],
  ['konfiguracja_13',['Konfiguracja',['../frontend.html#autotoc_md15',1,'']]],
  ['konfiguracja_20firebase_3a_20components_20firebase_20firebase_20ts_14',['Konfiguracja Firebase: components/firebase/firebase.ts',['../api.html#autotoc_md56',1,'']]],
  ['konfiguracja_20klienta_20frontend_15',['Konfiguracja Klienta (Frontend)',['../firebase.html#autotoc_md96',1,'']]],
  ['konfiguracja_20serwera_20backend_16',['Konfiguracja Serwera (Backend)',['../firebase.html#autotoc_md99',1,'']]],
  ['konfiguracja_20wstępna_17',['Konfiguracja wstępna',['../instalacja.html#autotoc_md121',1,'']]],
  ['konfiguracyjny_18',['Obiekt konfiguracyjny',['../firebase.html#autotoc_md98',1,'']]],
  ['kontakt_20i_20wsparcie_19',['Kontakt i wsparcie',['../kontakt.html',1,'']]],
  ['kroki_3a_20',['kroki:',['../instalacja.html#autotoc_md126',1,'Kroki:'],['../instalacja.html#autotoc_md128',1,'Kroki:']]]
];
