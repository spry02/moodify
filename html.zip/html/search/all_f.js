var searchData=
[
  ['na_20danych_20serwisy_0',['Operacje na Danych (Serwisy)',['../firebase.html#autotoc_md110',1,'']]],
  ['nawigacji_1',['Komponenty UI i nawigacji',['../frontend.html#autotoc_md38',1,'']]],
  ['notatki_20dla_20deweloperów_2',['Notatki dla deweloperów',['../api.html#autotoc_md80',1,'']]]
];
