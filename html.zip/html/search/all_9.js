var searchData=
[
  ['główne_20komponenty_0',['Główne komponenty',['../frontend.html#autotoc_md11',1,'']]],
  ['główny_1',['Cel główny',['../opis.html#autotoc_md1',1,'']]],
  ['główny_20punkt_20wejścia_3a_20app_20tsx_2',['Główny punkt wejścia: App.tsx',['../frontend.html#autotoc_md21',1,'']]],
  ['generatebutton_20tsx_3',['GenerateButton.tsx',['../frontend.html#autotoc_md41',1,'']]]
];
