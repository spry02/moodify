var searchData=
[
  ['z_20firebase_0',['8. Endpointy API powiązane z Firebase',['../backend.html#autotoc_md100',1,'']]],
  ['zadania_1',['Cele i zadania',['../cele.html',1,'']]],
  ['zadania_20realizacyjne_2',['Zadania realizacyjne',['../cele.html#autotoc_md4',1,'']]],
  ['zainicjalizowane_20usługi_3',['Zainicjalizowane usługi',['../backend.html#autotoc_md86',1,'']]],
  ['zależności_4',['Instalacja zależności',['../frontend.html#autotoc_md65',1,'']]],
  ['zmienne_20środowiska_5',['Zmienne środowiska',['../frontend.html#autotoc_md79',1,'']]],
  ['zmienne_20środowiskowe_6',['Zmienne środowiskowe',['../backend.html#autotoc_md90',1,'']]],
  ['zmienne_20tematu_3a_20maindashboard_20tsx_7',['Zmienne tematu: MainDashboard.tsx',['../frontend.html#autotoc_md72',1,'']]]
];
