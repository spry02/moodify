var searchData=
[
  ['wnioski_20i_20podsumowanie_0',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['wsparcie_1',['Kontakt i wsparcie',['../kontakt.html',1,'']]],
  ['wykonawcze_2',['Streszczenie wykonawcze',['../streszczenie.html',1,'']]]
];
