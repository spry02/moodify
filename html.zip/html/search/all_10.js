var searchData=
[
  ['o_20duplikacji_0',['Uwaga o duplikacji',['../backend.html#autotoc_md94',1,'']]],
  ['obiekt_20konfiguracyjny_1',['Obiekt konfiguracyjny',['../firebase.html#autotoc_md98',1,'']]],
  ['obrazów_2',['Model CNN dla obrazów',['../ml.html#autotoc_md116',1,'']]],
  ['obrazowego_20wersja_20bazowa_20backend_20model_5ftraining_20ipynb_3',['Trening modelu obrazowego - wersja bazowa (backend/model_training.ipynb)',['../backend.html#autotoc_md87',1,'']]],
  ['obrazowego_20wersja_20rozszerzona_20backend_20models_20model_5ftraining_20ipynb_4',['Trening modelu obrazowego - wersja rozszerzona (backend/models/model_training.ipynb)',['../backend.html#autotoc_md88',1,'']]],
  ['obszary_20do_20usprawnienia_5',['Obszary do usprawnienia',['../wnioski.html#autotoc_md133',1,'']]],
  ['ogólna_6',['Architektura ogólna',['../architektura.html#autotoc_md5',1,'']]],
  ['ogólne_7',['Informacje Ogólne',['../firebase.html#autotoc_md95',1,'']]],
  ['operacje_20na_20danych_20serwisy_8',['Operacje na Danych (Serwisy)',['../firebase.html#autotoc_md110',1,'']]],
  ['opis_20projektu_9',['Opis projektu',['../opis.html',1,'']]],
  ['osiągnięcia_10',['Osiągnięcia',['../wnioski.html#autotoc_md131',1,'']]]
];
