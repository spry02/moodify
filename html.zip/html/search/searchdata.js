var indexSectionsWithContent =
{
  0: "123abcdefgijklmnoprstuvwzś",
  1: "abdfiklmoprstuw"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

