var searchData=
[
  ['ui_20i_20nawigacji_0',['Komponenty UI i nawigacji',['../frontend.html#autotoc_md38',1,'']]],
  ['uruchomienie_1',['uruchomienie',['../instalacja.html',1,'Instalacja i uruchomienie'],['../api.html#autotoc_md62',1,'Instalacja i uruchomienie']]],
  ['uruchomienie_20w_20trybie_20development_2',['Uruchomienie w trybie development',['../api.html#autotoc_md65',1,'']]],
  ['usługi_3',['Zainicjalizowane usługi',['../firebase.html#autotoc_md97',1,'']]],
  ['userpanel_20tsx_4',['UserPanel.tsx',['../frontend.html#autotoc_md49',1,'']]],
  ['users_5',['Kolekcja users',['../firebase.html#autotoc_md108',1,'']]],
  ['usprawnienia_6',['Obszary do usprawnienia',['../wnioski.html#autotoc_md133',1,'']]],
  ['uwaga_20o_20duplikacji_7',['Uwaga o duplikacji',['../backend.html#autotoc_md94',1,'']]],
  ['uwierzytelnianie_8',['Uwierzytelnianie',['../firebase.html#autotoc_md102',1,'']]]
];
