var searchData=
[
  ['addmoodform_20tsx_0',['AddMoodForm.tsx',['../frontend.html#autotoc_md26',1,'']]],
  ['affectnet_1',['AffectNet',['../ml.html#autotoc_md113',1,'']]],
  ['analiza_20zbiorow_20moodify_5fdatasets_5fanalysis_20ipynb_2',['Analiza zbiorow (moodify_datasets_analysis.ipynb)',['../backend.html#autotoc_md89',1,'']]],
  ['analysisresult_20tsx_3',['AnalysisResult.tsx',['../frontend.html#autotoc_md36',1,'']]],
  ['api_4',['api',['../instalacja.html#autotoc_md124',1,'3. Spotify API'],['../api.html',1,'API']]],
  ['api_20api_20services_20firebase_20py_5',['Backend API (api/services/firebase.py)',['../firebase.html#autotoc_md104',1,'']]],
  ['api_20api_20ts_6',['Plik: components/api/api.ts',['../api.html#autotoc_md51',1,'']]],
  ['api_20backend_20rzeczywiste_7',['API Backend (rzeczywiste)',['../api.html#autotoc_md53',1,'']]],
  ['api_20do_20testowania_20bez_20backendu_8',['Mock API (do testowania bez backendu)',['../api.html#autotoc_md52',1,'']]],
  ['api_20fastapi_9',['Backend API (FastAPI)',['../backend.html',1,'']]],
  ['api_20powiązane_20z_20firebase_10',['Endpointy API powiązane z Firebase',['../firebase.html#autotoc_md111',1,'']]],
  ['api_20services_20firebase_20py_11',['Backend API (api/services/firebase.py)',['../firebase.html#autotoc_md104',1,'']]],
  ['app_20tsx_12',['Główny punkt wejścia: App.tsx',['../frontend.html#autotoc_md21',1,'']]],
  ['architektura_20i_20struktura_13',['Architektura i struktura',['../frontend.html#autotoc_md13',1,'']]],
  ['architektura_20ogólna_14',['Architektura ogólna',['../architektura.html#autotoc_md5',1,'']]],
  ['architektura_20systemu_15',['Architektura systemu',['../architektura.html',1,'']]],
  ['autentykacja_16',['Autentykacja',['../api.html#autotoc_md55',1,'']]],
  ['autentykacji_3a_20auth_17',['Komponenty autentykacji: Auth/',['../frontend.html#autotoc_md44',1,'']]],
  ['auth_18',['Komponenty autentykacji: Auth/',['../frontend.html#autotoc_md44',1,'']]],
  ['authpopup_20tsx_19',['AuthPopup.tsx',['../frontend.html#autotoc_md45',1,'']]],
  ['autorzy_20',['Autorzy',['../index.html#authors',1,'']]]
];
