var searchData=
[
  ['react_20typescript_0',['Frontend (React + TypeScript)',['../frontend.html',1,'']]]
];
