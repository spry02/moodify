var searchData=
[
  ['i_20cel_0',['Zakres i cel',['../backend.html#autotoc_md82',1,'']]],
  ['i_20mapowanie_20emocji_1',['Zrodla danych i mapowanie emocji',['../backend.html#autotoc_md84',1,'']]],
  ['i_20nawigacji_2',['Komponenty UI i nawigacji',['../frontend.html#autotoc_md38',1,'']]],
  ['i_20podsumowanie_3',['Wnioski i podsumowanie',['../wnioski.html',1,'']]],
  ['i_20struktura_4',['Architektura i struktura',['../frontend.html#autotoc_md13',1,'']]],
  ['i_20uruchomienie_5',['i uruchomienie',['../instalacja.html',1,'Instalacja i uruchomienie'],['../api.html#autotoc_md62',1,'Instalacja i uruchomienie']]],
  ['i_20wsparcie_6',['Kontakt i wsparcie',['../kontakt.html',1,'']]],
  ['i_20wyników_7',['Komponenty danych i wyników',['../frontend.html#autotoc_md31',1,'']]],
  ['informacje_20ogólne_8',['Informacje Ogólne',['../firebase.html#autotoc_md95',1,'']]],
  ['infrastruktura_9',['Infrastruktura',['../technologie.html#autotoc_md9',1,'']]],
  ['inicjalizacja_10',['Inicjalizacja',['../firebase.html#autotoc_md100',1,'']]],
  ['instalacja_20i_20uruchomienie_11',['instalacja i uruchomienie',['../api.html#autotoc_md62',1,'Instalacja i uruchomienie'],['../instalacja.html',1,'Instalacja i uruchomienie']]],
  ['instalacja_20zależności_12',['Instalacja zależności',['../api.html#autotoc_md64',1,'']]],
  ['instalacji_13',['Weryfikacja instalacji',['../instalacja.html#autotoc_md130',1,'']]],
  ['interfejsy_20komponentów_14',['Interfejsy komponentów',['../api.html#autotoc_md60',1,'']]],
  ['ipynb_15',['ipynb',['../backend.html#autotoc_md89',1,'Analiza zbiorow (moodify_datasets_analysis.ipynb)'],['../backend.html#autotoc_md85',1,'Preprocessing danych (data_preprocessing.ipynb)'],['../backend.html#autotoc_md90',1,'Test predykcji (backend/models/test_predictions.ipynb)'],['../backend.html#autotoc_md87',1,'Trening modelu obrazowego - wersja bazowa (backend/model_training.ipynb)'],['../backend.html#autotoc_md88',1,'Trening modelu obrazowego - wersja rozszerzona (backend/models/model_training.ipynb)'],['../backend.html#autotoc_md86',1,'Trening modelu tekstowego (model_training.ipynb)']]]
];
