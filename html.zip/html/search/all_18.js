var searchData=
[
  ['z_20firebase_0',['Endpointy API powiązane z Firebase',['../firebase.html#autotoc_md111',1,'']]],
  ['zadania_20realizacyjne_1',['Zadania realizacyjne',['../opis.html#autotoc_md4',1,'']]],
  ['zainicjalizowane_20usługi_2',['Zainicjalizowane usługi',['../firebase.html#autotoc_md97',1,'']]],
  ['zakres_20i_20cel_3',['Zakres i cel',['../backend.html#autotoc_md82',1,'']]],
  ['zależności_4',['Instalacja zależności',['../api.html#autotoc_md64',1,'']]],
  ['zaleznosci_5',['Zaleznosci',['../backend.html#autotoc_md92',1,'']]],
  ['zbiorow_20moodify_5fdatasets_5fanalysis_20ipynb_6',['Analiza zbiorow (moodify_datasets_analysis.ipynb)',['../backend.html#autotoc_md89',1,'']]],
  ['zmienne_20środowiska_7',['Zmienne środowiska',['../api.html#autotoc_md78',1,'']]],
  ['zmienne_20środowiskowe_8',['Zmienne środowiskowe',['../firebase.html#autotoc_md101',1,'']]],
  ['zmienne_20tematu_3a_20maindashboard_20tsx_9',['Zmienne tematu: MainDashboard.tsx',['../api.html#autotoc_md71',1,'']]],
  ['zrodla_20danych_20i_20mapowanie_20emocji_10',['Zrodla danych i mapowanie emocji',['../backend.html#autotoc_md84',1,'']]]
];
